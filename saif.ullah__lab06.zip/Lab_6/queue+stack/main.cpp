 #include <iostream>
 #include <stdlib.h>
using namespace std;

class queue{
private:
    int first;
    int last;
    int Array[10];
public:
    queue()
    {
        first=0;
        last=0;
        for(int i=0; i<10; i++)
        {
            Array[i]=-1;
        }
    }//

    void enqueue(int data)
    {
       if(last==10)
        cout<<"array is full"<<endl;
       else
       {
           Array[last]=data;
           last++;
       }
    }//end



       void dequeue()
       {
if(last==0)
    cout<<"array is empty "<<endl;
else
{
    last--;
    for(int i=0; i<last; i++)
    {
        Array[i]=Array[i+1];
    }
    for(int j=last; j<10; j++)
        Array[j]=-1;
}
       }//

void peak()
{
   if(last==0)
        cout<<"Array is empty "<<endl;
   else
   {
       cout<<" peak is "<<Array[first-1]<<endl;
   }
}//end


void isfull()
{
    if(last==10)
    {
        cout<<"array is Full "<<endl;
    }
    else
        cout<<"Array is not full"<<endl;
}//end

void Clear()
{
    for(int i=0; i<10; i++)
    {
        Array[i]=-1;
    }
}




void display()
{
    if(last==0)
        cout<<"EMPTY"<<endl;
    else
    {
        for(int i=0; i<10; i++)
        {
            cout<<" "<<Array[i];
        }
    }
}
};


//class stack
class Stack{
private:
    int first;
    int last;
    int Array[10];
public:
    Stack()
    {
        first=0;
        last=0;
        for(int i=0; i<10; i++)
        {
            Array[i]=-1;
        }
    }//

    void push(int data)
    {
       if(first==10)
        cout<<"array is full"<<endl;
       else
       {
           Array[first]=data;
           first++;
       }
    }//end



       void pop()
       {
if(first==0)
    cout<<"array is empty "<<endl;
else
{
    Array[first]=0;
    first--;
}
       }//

void peak()
{
   if(first==0)
        cout<<"Array is empty "<<endl;
   else
   {
       cout<<" peak is "<<Array[first-1]<<endl;
   }
}//end


void isfull()
{
    if(first==10)
    {
        cout<<"array is Full "<<endl;
    }
    else
        cout<<"Array is not full"<<endl;
}//end

void Clear()
{
    for(int i=0; i<10; i++)
    {
        Array[i]=-1;
    }
}




void display()
{
    if(first==0)
        cout<<"EMPTY"<<endl;
    else
    {
        for(int i=0; i<10; i++)
        {
            cout<<" "<<Array[i];
        }
    }
}
}; //////

class dynamic
{
private:
    int dyna[10];
    int first;
    int last;
public:
dynamic()
{
    for(int i=0; i<10; i++)
        dyna[i]=-1;
    first=0;
    last=0;
}

void add(int data)
{
    if(first>=9 && last ==0)
        cout<<"cannot Add"<<endl;
    else if(((first-last)==1 || (first-last)==-1) && first<last)
        cout<<"cannot Add this"<<endl;
    else
      {
          dyna[first]=data;
           first++;
      }
      if(first>9 &&last>=1 )  ///((first-last>1) || (first-last<-1))
        first=0;
}//END



void del()
{
    if(first==last)
        cout<<"Empty "<<endl;
    else {
            dyna[last]=-1;
            last++;
            if(last>9)
                last=0;
    }
}//END

void disp()
{
    for(int i=0; i<10; i++)
        cout<<"  "<<dyna[i];
        cout<<" "<<endl;
}

};




int main()
{
    int xi,xx;
    queue myq;
    dynamic dy;
int x=0,choice,data;

cout<<endl<<"1 for Stack 2 for Queue 3 for round array"<<endl<<endl;
cin>>choice;

if(choice==1)
{
    Stack mys;
    do{
system("CLS");
    cout<<endl<<"1 for push"<<endl;
cout<<"2 for pop"<<endl;
cout<<"3 for peak"<<endl;
cout<<"4 is full "<<endl;
cout<<"5 for clear "<<endl;
cout<<"6 for display "<<endl;
cin>>choice;
switch(choice)
    {
    case 1:
        cout<<"Enter  ";
        cin>>data;
        mys.push(data);
        break;
    case 2:
        mys.pop();
        break;
    case 3:
        mys.peak();
        break;
    case 4:
        mys.isfull();
        break;
    case 5:
        mys.Clear();
        break;
    case 6:
        mys.display();
        break;

    }//swtch
    cout<<endl<<"Enter -1 to exit "<<endl;
    cin>>x;
}while(x!=-1);
}//first loop
if(choice==2)
{
do{
system("CLS");
    cout<<endl<<"1 for enqueue"<<endl;
cout<<"2 for dequeue "<<endl;
cout<<"3 for peak"<<endl;
cout<<"4 is full "<<endl;
cout<<"5 for clear "<<endl;
cout<<"6 for display "<<endl;
cin>>choice;
switch(choice)
    {
    case 1:
        cout<<"Enter  ";
        cin>>data;
        myq.enqueue(data);
        break;
    case 2:
        myq.dequeue();
        break;
    case 3:
        myq.peak();
        break;
    case 4:
        myq.isfull();
        break;
    case 5:
        myq.Clear();
        break;
    case 6:
        myq.display();
        break;




    }//swtch


cout <<endl<<"Enter -1 to exit "<<endl;
cin>>x;
}while(x!=-1);
}


if(choice==3)
{
do{
        system("CLS");
    cout<<"1 for add"<<endl;
    cout<<"2 for del"<<endl;
    cout<<"3 for display"<<endl;
    cin>>xi;
    if(xi==1)
    {
        cout<<"Enter "<<endl;
        cin>>xx;
        dy.add(xx);
    }
    if(xi==2)
        dy.del();

    if(xi==3)
        dy.disp();
        cout<<endl<<"Enter -1 to Exit "<<endl;
        cin>>x;
}while(x!=-1);
}
    return 0;
}
